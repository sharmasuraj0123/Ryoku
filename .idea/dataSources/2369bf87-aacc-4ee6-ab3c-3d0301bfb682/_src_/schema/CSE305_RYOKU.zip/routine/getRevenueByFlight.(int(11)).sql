CREATE PROCEDURE getRevenueByFlight(IN flightId INT)
  BEGIN
    SELECT F.airline,F.flight_number, SUM(FL.base_fare * P.travel_class)
    FROM `FlightLegs` FL, `ReservationLegs` RL, `TravelClass` TC , `Reservation` R,
      `Passenger` P,  `Flights` F , `ReservationPassenger` RP
    WHERE R.id = RL.reservation_id AND RL.legs_id = FL.id
          AND F.id = flightId AND
          RP.passengers_id = P.id AND RP.reservation_id = R.id AND
          TC.Name = P.travel_class AND
          F.id = FL.flight_id;
    END;
