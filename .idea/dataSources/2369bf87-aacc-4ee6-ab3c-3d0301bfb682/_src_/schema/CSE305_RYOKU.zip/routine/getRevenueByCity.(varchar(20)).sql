CREATE PROCEDURE getRevenueByCity(IN cityName VARCHAR(20))
  BEGIN
    SELECT A.name, SUM(FL.base_fare * P.travel_class) AS Revenue_Generated
    FROM `FlightLegs` FL, `ReservationLegs` RL, `TravelClass` TC , `Reservation` R, `Passenger` P, `Airports` A , ReservationPassenger RP
    WHERE R.id = RL.reservation_id AND RL.legs_id = FL.id
          AND A.city = cityName AND
          RP.passengers_id = P.id AND RP.reservation_id = R.id AND
          TC.Name = P.travel_class AND
          (A.id = FL.departureAirport OR A.id = FL.arrivalAirport);

    END;
