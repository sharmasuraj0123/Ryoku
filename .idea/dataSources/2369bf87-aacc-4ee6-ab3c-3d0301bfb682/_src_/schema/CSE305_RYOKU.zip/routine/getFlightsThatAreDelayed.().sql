CREATE PROCEDURE getFlightsThatAreDelayed()
  BEGIN
	
	SELECT F.airline, F.Flight_number, A1.name AS 'Departs From', A2.name AS 'Arrives At', L.departure_status, L.arrival_status 
FROM FLIGHTS F, FLIGHTLEGS L , Airports A1, Airports A2 
WHERE  L.flight_id = F.id AND A1.id = L.departureAirport 
AND A2.id = L.arrivalAirport 
AND (L.dept_timestamp < L.departure_status OR L.arrv_timestamp < L.arrival_status);

END;
