CREATE PROCEDURE getMostSalesByCustomer()
  BEGIN
    SELECT P.FirstName, P.LastName, P.Phone, SUM(R.total_fare) AS total_sales_made
    FROM Reservation R, Customers C, Person P
    WHERE R.customer_id = C.AccountNumber AND P.id = C.person_id
    GROUP BY R.customer_id
    ORDER BY total_sales_made DESC
    LIMIT 1;
    END;
