CREATE PROCEDURE listMostSalesByCustRep()
  BEGIN
    SELECT P.FirstName, P.LastName, P.Phone, SUM(R.total_fare) AS total_sales_made
    FROM Reservation R, Employees E, Person P
    WHERE R.Employee_id = E.EmployeeID AND P.id = E.person_id
    GROUP BY R.employee_id
    ORDER BY total_sales_made DESC
    LIMIT 1;
    END;
