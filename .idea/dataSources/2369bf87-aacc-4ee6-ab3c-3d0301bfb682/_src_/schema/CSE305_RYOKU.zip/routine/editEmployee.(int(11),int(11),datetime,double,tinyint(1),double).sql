CREATE PROCEDURE editEmployee(IN empID   INT, IN SSN INT, IN startDate DATETIME, IN hourPay DOUBLE,
                              IN manager TINYINT(1), IN rating DOUBLE)
  BEGIN
UPDATE `Employees` SET `SSN` = SSN, `StartDate` = startDate, `HourlyPay` = hourPay ,
  `isManager` = manager, `Rating` = rating
WHERE `EmployeeID` = 'empID';
END;
