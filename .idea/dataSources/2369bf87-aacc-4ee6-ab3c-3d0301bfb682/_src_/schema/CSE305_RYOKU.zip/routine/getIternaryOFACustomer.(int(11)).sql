CREATE PROCEDURE getIternaryOFACustomer(IN customer_id_in INT)
  BEGIN

SELECT PS.reservations_id AS Reservation_Number, P.FirstName, P.LastName, PS.seat_number, PS.seat_preference, F.airline, F.flight_number, A1.name AS Departure_Airport, A2.name AS Arrival_Airport
FROM Reservation R, ReservationPassenger RP, Passenger PS, Person P, ReservationLegs RL, FlightLegs FL, Flights F, Airports A1, Airports A2
WHERE R.customer_id = customer_id_in
	AND R.id = PS.reservations_id
    AND PS.person_id = P.id
    AND RL.reservation_id = R.id
    AND FL.id = RL.legs_id
    AND FL.id = F.id
    AND FL.departureAirport = A1.id
    AND FL.arrivalAirport = A2.id  
    GROUP BY PS.id;
END;
