CREATE PROCEDURE getReservationsByACustomer(IN customer_account_number INT)
  BEGIN
    SELECT * FROM Reservation R where R.customer_id = customer_account_number;
    END;
