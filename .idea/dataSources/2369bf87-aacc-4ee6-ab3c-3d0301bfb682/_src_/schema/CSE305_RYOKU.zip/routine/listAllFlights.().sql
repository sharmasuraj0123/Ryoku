CREATE PROCEDURE listAllFlights()
  BEGIN
    SELECT 	F.airline, F.Flight_number, L.stopNum,A1.name AS DepartureAirport,
                                                  A2.name AS ArrivalAirport, L.dept_timestamp, L.arrv_timestamp, F.days_Op
    FROM FLIGHTS F, FLIGHTLEGS L, AIRPORTS A1, AIRPORTS A2
    WHERE L.flight_id = F.id AND L.departureAirport = A1.id AND L.arrivalAirport = A2.id;
    END;
