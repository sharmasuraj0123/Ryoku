CREATE PROCEDURE getRevenueByAirport(IN airportId INT)
  BEGIN
    SELECT A.name, SUM(FL.base_fare * P.travel_class) FROM `FlightLegs` FL, `ReservationLegs` RL, `TravelClass` TC , `Reservation` R, `Passenger` P, `Airports` A , ReservationPassenger RP
    WHERE R.id = RL.reservation_id AND RL.legs_id = FL.id
          AND A.id = airportId AND
          RP.passengers_id = P.id AND RP.reservation_id = R.id AND
          TC.Name = P.travel_class AND
          (A.id = FL.departureAirport OR A.id = FL.arrivalAirport);
    END;
