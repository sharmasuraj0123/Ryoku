CREATE PROCEDURE `getBestSellerFlight()`()
  BEGIN
	SELECT Concat (F.airline, ' ', F.Flight_number) AS 'Flight', SUM(R.numberOfPassengers) AS 'Passengers' 
	FROM `Flights` F, `FlightLegs` L, `Reservation` R, `ReservationLegs` RL 
	WHERE R.id = RL.reservation_id AND RL.legs_id = L.id AND F.id = L.flight_id
	GROUP BY F.id
	ORDER BY SUM(R.numberOfPassengers) DESC;
END;
