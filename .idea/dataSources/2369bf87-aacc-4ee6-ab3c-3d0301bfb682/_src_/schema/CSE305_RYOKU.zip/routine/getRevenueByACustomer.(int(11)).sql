CREATE PROCEDURE getRevenueByACustomer(IN customer_id_in INT)
  BEGIN
    SELECT R.customer_id, SUM(R.total_fare) AS Total_Revenue_Generated, COUNT(R.id) AS Times_Flights_Booked
    FROM Reservation R
    WHERE R.customer_id = customer_id_in;
    END;
