CREATE PROCEDURE deleteEmployee(IN empID INT)
  BEGIN
    DELETE FROM Employees WHERE EmployeeID = 'empID';
  END;
