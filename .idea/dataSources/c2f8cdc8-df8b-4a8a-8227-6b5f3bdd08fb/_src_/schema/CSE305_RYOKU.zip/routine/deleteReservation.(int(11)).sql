CREATE PROCEDURE deleteReservation(IN res_id INT)
  BEGIN
    DELETE  FROM ReservationLegs WHERE ReservationLegs.reservation_id = res_id;
   DELETE  FROM Reservation WHERE Reservation.id = res_id;
  END;
