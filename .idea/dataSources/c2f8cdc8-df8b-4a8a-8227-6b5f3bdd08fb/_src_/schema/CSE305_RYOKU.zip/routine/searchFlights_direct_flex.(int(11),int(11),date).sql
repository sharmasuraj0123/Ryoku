CREATE PROCEDURE searchFlights_direct_flex(IN source_id INT, IN dest_id INT, IN date_d DATE)
  BEGIN
    SELECT * FROM FlightLegs F
    WHERE F.departureAirport = source_id AND F.arrivalAirport = dest_id
          AND  Date(F.dept_timestamp) <= DATE_ADD(date_d, INTERVAL 3 DAY) AND
          Date(F.dept_timestamp) >= DATE_SUB(date_d, INTERVAL 3 DAY)
          AND F.dept_timestamp <  F.arrv_timestamp;
  END;
