CREATE PROCEDURE getCurrentReservationOfAFlight(IN leg_id_in INT)
  BEGIN

    SELECT P.FirstName, P.LastName, R.id AS Reservation_Number, PS.seat_number, PS.seat_preference
    FROM Reservation R, ReservationLegs RL, ReservationPassenger RP, Passenger PS, Person P
    WHERE RL.legs_id = leg_id_in
          AND RL.reservation_id = R.id
          AND R.id = RP.reservation_id
          AND RP.passengers_id = PS.id
          AND PS.person_id = P.id;
  END;
