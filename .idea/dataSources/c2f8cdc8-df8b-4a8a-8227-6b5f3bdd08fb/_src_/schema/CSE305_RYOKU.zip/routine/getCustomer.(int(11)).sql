CREATE PROCEDURE getCustomer(IN person_id INT)
  BEGIN
    SELECT * FROM Person P , Customers C
    WHERE p.id = C.person_id AND
          p.id = person_id AND
          C.person_id = person_id;
  END;
