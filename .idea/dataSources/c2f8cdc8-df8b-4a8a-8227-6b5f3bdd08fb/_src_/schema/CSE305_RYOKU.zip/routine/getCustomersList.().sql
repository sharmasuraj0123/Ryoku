CREATE PROCEDURE getCustomersList()
  BEGIN
    SELECT * FROM `Customers` C , Person p WHERE C.person_id = p.id;
  END;
