CREATE PROCEDURE getPassengersOfAReservation(IN reservationId INT)
  BEGIN
    SELECT * FROM Person P, Reservation R , Passenger PS
    WHERE R.id = reservationId AND R.id = PS.reservations_id
          AND P.id = PS.person_id;
  END;
