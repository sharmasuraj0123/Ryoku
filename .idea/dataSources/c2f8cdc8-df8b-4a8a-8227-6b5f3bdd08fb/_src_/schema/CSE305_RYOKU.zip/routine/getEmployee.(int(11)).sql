CREATE PROCEDURE getEmployee(IN person_id INT)
  BEGIN
    SELECT * FROM Person P , Employees E
    WHERE p.id = E.person_id AND
          p.id = person_id AND
          E.person_id = person_id;
  END;
