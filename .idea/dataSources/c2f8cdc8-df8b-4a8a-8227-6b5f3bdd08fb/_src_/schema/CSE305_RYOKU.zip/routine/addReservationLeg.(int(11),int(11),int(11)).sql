CREATE PROCEDURE addReservationLeg(IN reservation_id INT, IN leg_Id INT, IN leg_Num INT)
  BEGIN
    INSERT INTO `ReservationLegs`(`reservation_id`, `legs_id`, `legNum` )
    VALUES (reservation_id, leg_Id, leg_Num );
    END;
