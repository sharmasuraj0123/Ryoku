CREATE PROCEDURE getFlightSuggestionsForCustomer(IN custId INT)
  BEGIN
    SELECT F.airline, F.Flight_number,A1.name AS DepartureAirport , A2.name AS ArrivalAirport, L.dept_timestamp, L.arrv_timestamp, F.days_Op from `Flights` F, `FlightLegs` L , `Airports` A1, `Airports` A2, `Customers` C, `Reservation` R , `ReservationLegs` RL

    WHERE 	L.flight_id = F.id AND
           (L.departureAirport = A1.id AND L.arrivalAirport = A2.id) AND
           R.id = RL.reservation_id AND
           RL.legs_id = L.id AND
           C.AccountNumber = R.customer_id AND
           C.AccountNumber = custId;
  END;
