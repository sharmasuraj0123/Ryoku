CREATE PROCEDURE getReservationsOfACustomer(IN customer_id_in INT)
  BEGIN
    SELECT R.Id, R.customer_id, R.NumberOfPassengers, R.date, R.total_fare, R.booking_fee, R.fare_restrictions, R.lengthOfStay
    FROM Reservation R
    WHERE R.customer_Id = customer_id_in
    ORDER BY R.date DESC;
  END;
