CREATE PROCEDURE getCurrentReservationOfACustomer(IN customer_id_in INT)
  BEGIN
    SELECT R.id, R.customer_id, R.NumberOfPassengers, R.date, R.total_fare, R.booking_fee, R.fare_restrictions, R.lengthOfStay
    FROM Reservation R , ReservationLegs RL , FlightLegs FL
    WHERE R.customer_id = customer_id_in
          AND RL.legs_id = FL.id AND RL.reservation_id = R.id
          AND FL.dept_timestamp > CURRENT_TIMESTAMP
    ORDER BY R.date DESC;
  END;
