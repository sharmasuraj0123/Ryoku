CREATE PROCEDURE getFlightsOfAReservation(IN reservationId INT)
  BEGIN
    SELECT * FROM ReservationLegs RL, FlightLegs FL
    WHERE Rl.reservation_id = reservationId AND RL.legs_id = FL.id;
  END;
