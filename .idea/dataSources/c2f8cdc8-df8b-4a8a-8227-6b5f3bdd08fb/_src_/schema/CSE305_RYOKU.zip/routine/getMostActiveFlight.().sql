CREATE PROCEDURE getMostActiveFlight()
  BEGIN
    SELECT CONCAT (F.airline, F.Flight_number), BIT_COUNT(F.days_Op) AS 'Days Operated in week'
    FROM Flights F
    ORDER BY BIT_COUNT(F.days_Op) DESC;
  END;
