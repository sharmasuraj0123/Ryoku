CREATE PROCEDURE getReservationsByCustomerId(IN cust_id INT)
  BEGIN
    SELECT * FROM Reservation R
    WHERE R.customer_id = cust_id;
  END;
