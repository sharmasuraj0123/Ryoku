CREATE PROCEDURE addEmployee(IN firstName VARCHAR(20), IN lastName VARCHAR(20), IN address VARCHAR(50),
                             IN city      VARCHAR(20), IN state CHAR(2), IN zipCode INT(5), IN phone BIGINT(10),
                             IN SSN       INT, IN startDate DATETIME, IN hourPay DOUBLE, IN manager TINYINT(1),
                             IN rating    DOUBLE, IN email VARCHAR(30), IN password VARCHAR(30))
  BEGIN
    INSERT INTO `Person`(`id`, `FirstName`, `LastName`,emailAddress,password, `Address`, `City_Town`, `State`, `ZipCode`, `Phone`)
    VALUES (NULL, firstName, lastName, email, password ,address, city, state, zipCode, Phone);

    SET @person_id = LAST_INSERT_ID();

    INSERT INTO `Employees`(EmployeeID, person_id, SSN, StartDate, HourlyPay , isManager, Rating)
    VALUES (NULL, @person_id, SSN, startDate, hourPay, manager, rating);

  END;
