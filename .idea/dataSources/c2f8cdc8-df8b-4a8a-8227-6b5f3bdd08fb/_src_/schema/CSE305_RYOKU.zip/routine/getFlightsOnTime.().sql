CREATE PROCEDURE getFlightsOnTime()
  BEGIN
    SELECT F.airline, F.Flight_number, A1.name AS 'Departs From', A2.name AS 'Arrives At', L.dept_timestamp, L.arrv_timestamp
    FROM FLIGHTS F, FLIGHTLEGS L , Airports A1, Airports A2
    WHERE  L.flight_id = F.id AND A1.id = L.departureAirport
           AND A2.id = L.arrivalAirport
           AND (L.dept_timestamp = L.departure_status AND L.arrv_timestamp = L.arrival_status);
  END;
