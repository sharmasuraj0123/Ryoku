CREATE PROCEDURE editCustomer(IN firstName VARCHAR(20), IN lastName VARCHAR(20), IN address VARCHAR(50),
                              IN city      VARCHAR(20), IN state CHAR(2), IN zipCode INT(5), IN phone BIGINT(10),
                              IN email     VARCHAR(20), IN date_d DATETIME, IN creditCardNum BIGINT(16),
                              IN rating    DOUBLE, IN personId INT, IN custId INT)
  BEGIN
    UPDATE `Person` SET `FirstName` = firstName, `LastName` = lastName, `Address` = address,
      `City_Town` = city, `State` = state, `ZipCode` = zipCode, `Phone` = phone
    WHERE `Person`.`id` = personId;

    UPDATE `Customers` SET `EmailAddress` = email, `AccountCreationDate` = date_d,
      `CreditCardNumber` = creditCardNum, `Rating` = rating
    WHERE `Customers`.`AccountNumber` = custId;

  END;
